package vehicle_colour;

public enum Colour {
	WHITE, SILVER, BLACK, RED, BLUE;

}

package custom_exception;

public class InvalidColourException extends Exception {
	public InvalidColourException(String mesg)
	{
		super(mesg);
	}

}
